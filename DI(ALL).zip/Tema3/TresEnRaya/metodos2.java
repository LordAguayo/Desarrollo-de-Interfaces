package TresEnRaya;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class metodos2 extends JButton implements ActionListener {
	private int cont = 0;
	private JButton b1;
	private JButton b2;
	private JButton b3;
	private JButton b4;
	private JButton b5;
	private JButton b6;
	private JButton b7;
	private JButton b8;
	private JButton b9;
	private JButton bPausa;
	private JButton bPlay;
	private JButton bNuevo;

	public metodos2(JButton bt1, JButton bt2, JButton bt3, JButton bt4, JButton bt5, JButton bt6, JButton bt7,
			JButton bt8, JButton bt9) {
		b1 = bt1;
		b2 = bt2;
		b3 = bt3;
		b4 = bt4;
		b5 = bt5;
		b6 = bt6;
		b7 = bt7;
		b8 = bt8;
		b9 = bt9;
		for (int cont = 0, cont2 = 0; cont == cont2; cont2 = cont * 2, cont++)
			if (b1.equals(b2) && b1.equals(b3) || b1.equals(b4) && b1.equals(b7) || b1.equals(b5) && b1.equals(b9)
					|| b2.equals(b5) && b2.equals(b8) || b3.equals(b5) && b3.equals(b7)
					|| b3.equals(b6) && b3.equals(b9) || b4.equals(b5) && b4.equals(b6)
					|| b7.equals(b8) && b7.equals(b9)) {
				if (cont % 2 == 0) {
					JOptionPane.showMessageDialog(getParent(), "Gana el jugador 1");
					cont = cont2;
				} else {
					JOptionPane.showMessageDialog(getParent(), "Gana el jugador 2");
					cont = cont2;
				}
			}
	}

	public void actionPerformed(ActionEvent e) {

	}

}
