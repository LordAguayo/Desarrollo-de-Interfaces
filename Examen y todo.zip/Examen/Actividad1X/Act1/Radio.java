package Act1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Radio extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Radio frame = new Radio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Radio() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 580, 475);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnRegistro = new JMenu("Registro");
		mnRegistro.setMnemonic('R');
		menuBar.add(mnRegistro);

		JMenu mnRegistrar = new JMenu("Registrar");
		mnRegistrar.setMnemonic('R');
		mnRegistro.add(mnRegistrar);

		JMenu mnBorrar = new JMenu("Borrar");
		mnBorrar.setMnemonic('B');
		mnRegistro.add(mnBorrar);

		JMenu mnFrecuencia = new JMenu("Frecuencia");
		menuBar.add(mnFrecuencia);

		JMenu mnIncrementar = new JMenu("Incrementar");
		mnFrecuencia.add(mnIncrementar);

		JMenu mnDecrementar = new JMenu("Decrementar");
		mnFrecuencia.add(mnDecrementar);

		JMenu mnVolumen = new JMenu("Volumen");
		menuBar.add(mnVolumen);

		JMenu mnAumentar = new JMenu("Aumentar");
		mnVolumen.add(mnAumentar);

		JMenu mnDisminuir = new JMenu("Disminuir");
		mnVolumen.add(mnDisminuir);

		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);

		JMenu mnHelp_1 = new JMenu("Help");
		mnHelp.add(mnHelp_1);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblUsuario = new JLabel("USUARIO");
		lblUsuario.setBounds(10, 11, 46, 14);
		contentPane.add(lblUsuario);

		JLabel lblPwd = new JLabel("PWD");
		lblPwd.setBounds(10, 38, 46, 14);
		contentPane.add(lblPwd);

		textField = new JTextField();
		textField.setBounds(78, 8, 159, 20);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(78, 35, 159, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		JLabel lblRegistro = new JLabel("REGISTRO");
		lblRegistro.setBounds(298, 11, 62, 14);
		contentPane.add(lblRegistro);

		textField_2 = new JTextField();
		textField_2.setBounds(298, 35, 256, 327);
		contentPane.add(textField_2);
		textField_2.setColumns(10);

		JButton btnNewButton = new JButton("CONECTAR");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		btnNewButton.setBounds(10, 63, 227, 23);
		contentPane.add(btnNewButton);

		JLabel lblFrecuencia = new JLabel("FRECUENCIA");
		lblFrecuencia.setBounds(10, 109, 73, 14);
		contentPane.add(lblFrecuencia);

		textField_3 = new JTextField();
		textField_3.setBounds(10, 134, 227, 71);
		contentPane.add(textField_3);
		textField_3.setColumns(10);

		JButton btnNewButton_1 = new JButton("<--");
		btnNewButton_1.setBounds(10, 211, 103, 23);
		contentPane.add(btnNewButton_1);

		JButton button = new JButton("-->");
		button.setBounds(134, 211, 103, 23);
		contentPane.add(button);

		JButton btnNewButton_2 = new JButton("REGISTRAR");
		btnNewButton_2.setBounds(10, 245, 227, 23);
		contentPane.add(btnNewButton_2);

		JButton btnBorrar = new JButton("BORRAR");
		btnBorrar.setBounds(298, 373, 256, 23);
		contentPane.add(btnBorrar);

		JLabel lblVolumen = new JLabel("VOLUMEN");
		lblVolumen.setBounds(10, 291, 73, 14);
		contentPane.add(lblVolumen);

		Volumen progressBar = new Volumen();
		progressBar.setBounds(10, 316, 227, 30);
		contentPane.add(progressBar);

		JButton bMinus = new JButton("-");
		bMinus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bMinus.isEnabled()) {
					if (progressBar.getValue() <= 10) {
						progressBar.setValue(00);
					} else if (progressBar.getValue() <= 20) {
						progressBar.setValue(10);
					} else if (progressBar.getValue() <= 30) {
						progressBar.setValue(20);
					} else if (progressBar.getValue() <= 40) {
						progressBar.setValue(30);
					} else if (progressBar.getValue() <= 50) {
						progressBar.setValue(40);
					} else if (progressBar.getValue() <= 60) {
						progressBar.setValue(50);
					} else if (progressBar.getValue() <= 70) {
						progressBar.setValue(60);
					} else if (progressBar.getValue() <= 80) {
						progressBar.setValue(70);
					} else if (progressBar.getValue() <= 90) {
						progressBar.setValue(80);
					} else if (progressBar.getValue() <= 100) {
						progressBar.setValue(90);
					}
				}
			}
		});
		bMinus.setBounds(10, 357, 89, 23);
		contentPane.add(bMinus);

		JButton bPlus = new JButton("+");
		bPlus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bPlus.isEnabled()) {
					if (progressBar.getValue() <= 0) {
						progressBar.setValue(10);
					} else if (progressBar.getValue() <= 10) {
						progressBar.setValue(20);
					} else if (progressBar.getValue() <= 20) {
						progressBar.setValue(30);
					} else if (progressBar.getValue() <= 30) {
						progressBar.setValue(40);
					} else if (progressBar.getValue() <= 40) {
						progressBar.setValue(50);
					} else if (progressBar.getValue() <= 50) {
						progressBar.setValue(60);
					} else if (progressBar.getValue() <= 60) {
						progressBar.setValue(70);
					} else if (progressBar.getValue() <= 70) {
						progressBar.setValue(80);
					} else if (progressBar.getValue() <= 80) {
						progressBar.setValue(90);
					} else if (progressBar.getValue() <= 90) {
						progressBar.setValue(100);
					}
				}
			}
		});
		bPlus.setBounds(148, 357, 89, 23);
		contentPane.add(bPlus);

		JRadioButton rdbtnFm = new JRadioButton("FM");
		rdbtnFm.setBounds(243, 134, 109, 23);
		contentPane.add(rdbtnFm);

		JRadioButton rdbtnAm = new JRadioButton("AM");
		rdbtnAm.setBounds(243, 158, 109, 23);
		contentPane.add(rdbtnAm);
	}
}
