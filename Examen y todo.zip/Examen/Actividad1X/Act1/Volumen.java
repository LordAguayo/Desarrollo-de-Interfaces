package Act1;

import java.awt.Color;

import javax.swing.JProgressBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Volumen extends JProgressBar implements ChangeListener {
	private int volMax = 100;
	private int volMin = 0;

	public Volumen() {
		this.setValue(0);
		this.setStringPainted(true);
		this.setMaximum(volMax);
		this.addChangeListener(this);
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		if (this.getValue() <= 10) {
			this.setForeground(Color.CYAN);
		}
		if (this.getValue() >= 11 && this.getValue() <= 30) {
			this.setForeground(Color.BLUE);
		}
		if (this.getValue() >= 31 && this.getValue() <= 50) {
			this.setForeground(Color.GREEN);
		}
		if (this.getValue() >= 51 && this.getValue() <= 70) {
			this.setForeground(Color.YELLOW);
		}
		if (this.getValue() >= 71 && this.getValue() <= 80) {
			this.setForeground(Color.ORANGE);
		}
		if (this.getValue() >= 81 && this.getValue() == 100) {
			this.setForeground(Color.RED);
		}

	}

}
