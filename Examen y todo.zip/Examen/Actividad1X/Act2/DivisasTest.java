package Act2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Act2.ConversionDivisas.Divisas;

class DivisasTest {
	// Test todo correcto
	@Test
	void test() {
		ConversionDivisas conv = new ConversionDivisas();
		double resultado = conv.conversionEnEuros(50, Divisas.DOLAR);
		assertEquals(55.55555555555556, resultado);
		double resultado2 = conv.conversionEnEuros(50, Divisas.EURO);
		assertEquals(50, resultado2);
		double resultado3 = conv.conversionEnEuros(50, Divisas.LIBRA);
		assertEquals(43.10344827586207, resultado3);
		double resultado4 = conv.conversionEnEuros(50, Divisas.YEN);
		assertEquals(6024.096385542169, resultado4);
	}

	// Test que dan mal los dos ultimos
	@Test
	void test2() {
		ConversionDivisas conv = new ConversionDivisas();
		double resultado = conv.conversionEnEuros(30, Divisas.DOLAR);
		assertEquals(33.333333333333336, resultado);
		double resultado2 = conv.conversionEnEuros(30, Divisas.EURO);
		assertEquals(30.0, resultado2);
		double resultado3 = conv.conversionEnEuros(30, Divisas.LIBRA);
		assertEquals(43.10344827586207, resultado3);
		double resultado4 = conv.conversionEnEuros(30, Divisas.YEN);
		assertEquals(6024.096385542169, resultado4);
	}

	// Test que salta excepcion de poner 0
	@Test
	void test3() {
		ConversionDivisas conv = new ConversionDivisas();
		double resultado = conv.conversionEnEuros(0, Divisas.DOLAR);
		assertEquals(0.0, resultado);

		double resultado2 = conv.conversionEnEuros(0, Divisas.EURO);
		assertEquals(0.0, resultado2);
		double resultado3 = conv.conversionEnEuros(0, Divisas.LIBRA);
		assertEquals(0.0, resultado3);
		double resultado4 = conv.conversionEnEuros(0, Divisas.YEN);
		assertEquals(0.0, resultado4);
	}

	// Test todo erroneo
	@Test
	void test4() {
		ConversionDivisas conv = new ConversionDivisas();
		double resultado = conv.conversionEnEuros(550, Divisas.DOLAR);
		assertEquals(55.55555555555556, resultado);
		double resultado2 = conv.conversionEnEuros(550, Divisas.EURO);
		assertEquals(50, resultado2);
		double resultado3 = conv.conversionEnEuros(550, Divisas.LIBRA);
		assertEquals(43.10344827586207, resultado3);
		double resultado4 = conv.conversionEnEuros(550, Divisas.YEN);
		assertEquals(6024.096385542169, resultado4);
	}
	/*
	 * Resultados obtenidos: - Metodo de conversion en 0,07 segundos.
	 * Excepcion salta en el Test 3 
	 * Prueba de que la conversion es correcta en el Test1
	 */

}
