package Act2;

import Act2.ConversionDivisas.Divisas;

public class main {

	public static void main(String[] args) {
		ConversionDivisas conv = new ConversionDivisas();
		System.out.println(conv.conversionEnEuros(100, Divisas.YEN));
	}

}
