package Menu;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
/**
 * 
 * @author gonza
 *
 */
public class nav extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					nav frame = new nav();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public nav() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 452, 476);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		mnFile.setMnemonic('F');

		JMenu mnNewFile = new JMenu("New file");
		mnNewFile.setMnemonic('n');
		mnFile.add(mnNewFile);
		

		JMenu mnImportFile = new JMenu("Import file");
		mnImportFile.setMnemonic('i');
		mnFile.add(mnImportFile);

		JMenu mnSaveFile = new JMenu("Save file");
		mnSaveFile.setMnemonic('s');
		mnFile.add(mnSaveFile);

		JMenu mnSaveFileAs = new JMenu("Save file as");
		mnSaveFileAs.setMnemonic('l');
		mnFile.add(mnSaveFileAs);

		JMenu mnEditar = new JMenu("Insert");
		menuBar.add(mnEditar);
		mnEditar.setMnemonic('G');

		JMenu mnSearch = new JMenu("Search");
		menuBar.add(mnSearch);
		mnSearch.setMnemonic('S');

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JPopupMenu popupMenu = new JPopupMenu();
		popupMenu.setBounds(0, 0, 51, 50);
		addPopup(contentPane, popupMenu);

		JMenu mnNuevo = new JMenu("New");
		popupMenu.add(mnNuevo);

		JMenu mnCargar = new JMenu("Load");
		popupMenu.add(mnCargar);

		JMenu mnSave = new JMenu("Save");
		popupMenu.add(mnSave);

		contentPane.setLayout(null);
	}

	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}

			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}

			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
