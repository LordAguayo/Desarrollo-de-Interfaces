package Examen_28_10_19;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.JButton;
import java.awt.TextArea;
import java.awt.Button;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Examen extends JFrame {

	private JPanel contentPane;
	private JTextField textNombre;
	private JTextField textApellido;
	private JTextField textDni;
	private JTextField textCuantia;
	private JTextField textNombre2;
	private JTextField textApellido2;
	private JTextField textDni2;
	private TextArea textLog = new TextArea();
	private String vacia = "";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Examen frame = new Examen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Examen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 623, 484);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnTransferencia = new JMenu("Transferencia");
		menuBar.add(mnTransferencia);

		JMenuItem mntmNewMenuItem = new JMenuItem("Efectuar");
		mntmNewMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_MASK));
		mnTransferencia.add(mntmNewMenuItem);

		JMenuItem mntmReset = new JMenuItem("Reset");
		mntmReset.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_MASK));
		mnTransferencia.add(mntmReset);

		JMenu mnNewMenu = new JMenu("Log");
		menuBar.add(mnNewMenu);

		JMenuItem mntmBorrar = new JMenuItem("Borrar");
		mntmBorrar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, InputEvent.CTRL_MASK));
		mnNewMenu.add(mntmBorrar);

		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);

		JMenuItem mntmConversionDeDivisas = new JMenuItem("Conversion de divisas");
		mnHelp.add(mntmConversionDeDivisas);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(46, 41, 54, 14);
		contentPane.add(lblNombre);

		JLabel lblApellidos = new JLabel("Apellidos:");
		lblApellidos.setBounds(39, 66, 74, 14);
		contentPane.add(lblApellidos);

		textNombre = new JTextField();
		textNombre.setBounds(110, 38, 139, 20);
		contentPane.add(textNombre);
		textNombre.setColumns(10);

		textApellido = new JTextField();
		textApellido.setBounds(110, 65, 139, 20);
		contentPane.add(textApellido);
		textApellido.setColumns(10);

		textDni = new JTextField();
		textDni.setBounds(110, 96, 139, 20);
		contentPane.add(textDni);
		textDni.setColumns(10);

		JLabel lblDni = new JLabel("Dni:");
		lblDni.setBounds(46, 99, 46, 14);
		contentPane.add(lblDni);

		JLabel lblMtodo = new JLabel("Metodo:");
		lblMtodo.setBounds(46, 153, 46, 14);
		contentPane.add(lblMtodo);

		JRadioButton rdbtnEfectivo = new JRadioButton("Efectivo");
		rdbtnEfectivo.setBounds(110, 123, 109, 23);
		contentPane.add(rdbtnEfectivo);

		JRadioButton rdbtnTarjeta = new JRadioButton("Tarjeta");
		rdbtnTarjeta.setBounds(110, 149, 109, 23);
		contentPane.add(rdbtnTarjeta);

		JRadioButton rdbtnPaypal = new JRadioButton("PayPal");
		rdbtnPaypal.setBounds(110, 175, 109, 23);
		contentPane.add(rdbtnPaypal);

		JLabel lblCuanta = new JLabel("Cuantia:");
		lblCuanta.setBounds(46, 208, 46, 14);
		contentPane.add(lblCuanta);

		JLabel lblDivisa = new JLabel("Divisa:");
		lblDivisa.setBounds(46, 239, 46, 14);
		contentPane.add(lblDivisa);

		textCuantia = new JTextField();
		textCuantia.setBounds(110, 205, 139, 20);
		contentPane.add(textCuantia);
		textCuantia.setColumns(10);

		JComboBox comboBox = new JComboBox();
		comboBox.setModel(
				new DefaultComboBoxModel(new String[] { "Dolar Estadounidense", "Yen", "Euro", "Libra Esterlina" }));
		comboBox.setToolTipText("Dolar estadounidense\r\nYen\r\nEuro\r\nLibra esterlina\r\n");
		comboBox.setBounds(110, 236, 139, 20);
		contentPane.add(comboBox);

		JLabel lblEmisor = new JLabel("Emisor");
		lblEmisor.setBounds(144, 11, 46, 14);
		contentPane.add(lblEmisor);

		JLabel lblReceptor = new JLabel("Receptor");
		lblReceptor.setBounds(415, 11, 46, 14);
		contentPane.add(lblReceptor);

		JLabel label = new JLabel("Nombre:");
		label.setBounds(332, 41, 61, 14);
		contentPane.add(label);

		JLabel lblApellidos_1 = new JLabel("Apellidos:");
		lblApellidos_1.setBounds(332, 68, 61, 14);
		contentPane.add(lblApellidos_1);

		JLabel label_2 = new JLabel("Dni:");
		label_2.setBounds(332, 99, 46, 14);
		contentPane.add(label_2);

		JButton btnEfectuar = new JButton("Efectuar");
		btnEfectuar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textNombre.getText() != vacia && textNombre2.getText() != vacia && textApellido.getText() != vacia
						&& textApellido2.getText() != vacia && textCuantia.getText() != vacia
						&& textDni.getText() != vacia && textDni2.getText() != vacia) {
					textLog.setText(textNombre.getText() + "  " + textApellido.getText() + "  " + " & " + " DNI "
							+ textDni + "    >> " + textNombre2 + "  " + textApellido2 + "  " + " & " + textDni2
							+ "     >>" + textCuantia + "  euros  " + "  ");
				}
			}
		});
		btnEfectuar.setBounds(332, 123, 94, 44);
		contentPane.add(btnEfectuar);

		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(getParent(), "�Seguro que quieres borrar el registro?", "Efectuar",
						JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
					textNombre.setText("");
					textNombre2.setText("");
					textApellido.setText("");
					textApellido2.setText("");
					textDni.setText("");
					textDni2.setText("");
					rdbtnEfectivo.setSelected(false);
					rdbtnPaypal.setSelected(false);
					rdbtnTarjeta.setSelected(false);
				}

			}
		});
		btnReset.setBounds(425, 123, 100, 44);
		contentPane.add(btnReset);

		textNombre2 = new JTextField();
		textNombre2.setColumns(10);
		textNombre2.setBounds(399, 38, 126, 20);
		contentPane.add(textNombre2);

		textApellido2 = new JTextField();
		textApellido2.setColumns(10);
		textApellido2.setBounds(399, 65, 126, 20);
		contentPane.add(textApellido2);

		textDni2 = new JTextField();
		textDni2.setColumns(10);
		textDni2.setBounds(399, 96, 126, 20);
		contentPane.add(textDni2);

		textLog.setBounds(10, 262, 466, 139);
		contentPane.add(textLog);

		Button button = new Button("Borrar");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(getParent(), "Esta seguro que quiere borrar el log", "Efectuar",
						JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
					textLog.setText("");
				}
			}
		});
		button.setBounds(482, 262, 114, 28);
		contentPane.add(button);

		ButtonGroup grupo1 = new ButtonGroup();
		grupo1.add(rdbtnEfectivo);
		grupo1.add(rdbtnPaypal);
		grupo1.add(rdbtnTarjeta);

	}
}
