package JUNIT;

public @interface Parameters {

}
