package Calcu;

/**
 * 
 */
import java.util.Scanner;

/**
 * 
 * @author gonza
 *
 */
public class CalculadoraV2 {
	/**
	 * 
	 * @param args
	 */

	public static void main() {
		/*
		 * Realizar una calculadora mediante vectores y con variables a�adidas estos.
		 * Utilizar excepciones para casos concretos de divison, multiplicacion...
		 */
		double[] a = new double[10];
		double[] b = new double[10];
		double[] r = new double[10];
		int last = 0;
		String signo = "";
		// Variables para guardar los resultados y los numeros.
		System.out.println("---------------Calculator---------------");
		System.out.println("-----------------------------------------");
		Scanner sc = new Scanner(System.in);
		System.out.println("Do you want to turn on the calculator?(y or n)");
		System.out.println("-----------------------------------------");
		String on = sc.next();
		if ((on.contentEquals("n"))) {
			System.out.println("turn off");
		} else {
			System.out.println("--------------...Let's go...--------------");
			calcu(a, b, r, last, signo);
		}
	}

	public static double[] calcu(double[] d, double[] e, double[] t, int lst, String simbol) {
		Scanner x = new Scanner(System.in);
		double[] v1 = new double[10];
		double[] v2 = new double[10];
		double[] rst = new double[10];
		System.out.println(
				"Welcome to the calculator.\r\n" + "All operations have two operands (int) and one operator\r\n"
						+ "The allowed operators are:\r\n" + "+ sum\r\n" + "- subtraction\r\n" + "* multiplication\r\n"
						+ "/ division\r\n" + "% rest\r\n" + "! raise");
		System.out.println("-----------------------------------------");
		System.out.println("Enter value 1");
		for (int i = 0; i < v1.length; i++) {
			v1[i] = x.nextInt();
			System.out.println("What are you going to do?(+,-,/,* or !.)");
			simbol = x.next();
			operacion(simbol);
			System.out.println("Enter value 2");
			v2[i] = x.nextInt();
			lst++;
			if (simbol.equals("+")) {
				rst[lst] = suma(v1[i], v2[i]);
				System.out.println("Result: " + suma(v1[i], v2[i]));
				System.out.println("--- Situaci�n: ---: ");
				System.out.println(v1[i] + " " + simbol + " " + v2[i] + " = " + " " + rst[lst]);
			}
			if (simbol.equals("-")) {
				rst[lst] = resta(v1[i], v2[i]);
				System.out.println("Result: " + resta(v1[i], v2[i]));
				System.out.println("--- Situaci�n: ---: ");
				System.out.println(v1[i] + " " + simbol + " " + v2[i] + " = " + " " + rst[lst]);
				;
			}
			if (simbol.equals("/")) {
				rst[lst] = division(v1[i], v2[i]);
				System.out.println("Result: " + division(v1[i], v2[i]));
				System.out.println("--- Situaci�n: ---: ");
				System.out.println(v1[i] + " " + simbol + " " + v2[i] + " = " + " " + rst[lst]);
			}
			if (simbol.equals("*")) {
				rst[lst] = multiplicacion(v1[i], v2[i]);
				System.out.println("Result: " + multiplicacion(v1[i], v2[i]));
				System.out.println("--- Situaci�n: ---: ");
				System.out.println(v1[i] + " " + simbol + " " + v2[i] + " = " + " " + rst[lst]);
			}
			if (simbol.equals("!")) {
				rst[lst] = elevar(v1[i], v2[i]);
				System.out.println("Result: " + elevar(v1[i], v2[i]));
				System.out.println("--- Situaci�n: ---: ");
				System.out.println(v1[i] + " " + simbol + " " + v2[i] + " = " + " " + rst[lst]);
			}
			reset(d, e, rst, lst, simbol);
		}
		return null;
	}

	// METODO DE REAJUSTE DE LOS VECTORES
	private void reajuste(int[] v) {
		int i;
		int aux[] = new int[v.length + 5];
		for (i = 0; i < aux.length; i++) {
			aux[i] = v[i];
		}
		v = aux;
	}

	// Metodo de guardar resultado
	public static double[] guardar(double[] x) {
		return null;
	}

	// METODO DE RESET
	public static String reset(double[] d, double[] e, double[] t, int lst, String simbol) {
		String restart = "";
		Scanner x = new Scanner(System.in);
		System.out.println("You want to continue?(y or n)");
		restart = x.next();
		if ((restart.contentEquals("y"))) {
			calcu(d, e, t, lst, simbol);
		} else {
			System.out.println("Goodbye!!");
		}
		return null;
	}

	/*
	 * Metodo que ejecuta la operacion a utilizar y devuelve la excepcion
	 */
	public static String operacion(String s) {
		try {
			exceSigno(s);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return s;
	}

	/*
	 * Operacion que suma los dos valores
	 */
	public static double suma(double s1, double s2) {
		try {
			excep(s1, s2);
		} catch (Exception e) {
			System.out.println(e.getMessage());

		}
		return s1 + s2;
	}

	// Operacion que resta los dos valores
	public static double resta(double r1, double r2) {
		try {
			exceR(r1, r2);
		} catch (Exception e) {
			System.out.println(e.getMessage());

		}
		return r1 - r2;
	}

	// Operacion que multiplica los dos valores
	public static double multiplicacion(double m1, double m2) {
		try {
			exceM(m1, m2);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return m1 * m2;
	}

	// Operacion que divide los dos valores
	public static double division(double d1, double d2) {
		try {
			exceD(d1, d2);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return d1 / d2;
	}

	// Operacion que eleva el primer valor poniendo de exponente el segundo
	public static double elevar(double e1, double e2) {
		return (int) Math.pow((int) e1, (int) e2);
	}

	// METODO DE EXCEPCION
	// Excepcion de igualdad de ceros
	public static void excep(double x, double y) throws Exception {
		if (x == 0 && y == 0) {
			Exception ex = new Exception("This is going to be 0");
			throw ex;
		}
	}

	// Excepcion de multiplicacion por cero
	public static void exceM(double x, double y) throws Exception {
		if (x == 0 || y == 0) {
			Exception ex = new Exception("This is going to be 0");
			throw ex;
		}
	}

	// Excepcion de resta negativa
	public static void exceR(double x, double y) throws Exception {
		if ((x - y) < 0) {
			Exception ex = new Exception("You got a negative number");
			throw ex;
		}
	}

	// Excepcion de division que da infinito
	public static void exceD(double x, double y) throws Exception {
		if (y == 0) {
			Exception ex = new Exception("You can't divide with a 0 in the divisor");
			throw ex;
		}
	}

	public static void exceSigno(String s) throws Exception {
		if (s != "+" || s != "-" || s != "x" || s != "/") {
		} else {
			Exception ex = new Exception("This is not a simbol");
			throw ex;
		}
	}
}
