package Pactometro;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.GridLayout;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JProgressBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;

/**
 * Jframe que contiene los elementos de la clase que estamos usando
 * 
 * @author gonza
 *
 */
public class Pactometro extends JFrame {

	private JPanel contentPane;
	private JTextField textPsoe;
	private JTextField textPP;
	private JTextField textVox;
	private JTextField textUP;
	private JTextField textERC;
	private JTextField textCs;
	private JTextField textJxCat;
	private JTextField textPNV;
	private JTextField textBildu;
	private JTextField textMP;
	private JTextField textCUP;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pactometro frame = new Pactometro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Pactometro() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 470);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnVotos = new JMenu("Votos");
		menuBar.add(mnVotos);

		JMenuItem mntmRiniciar = new JMenuItem("Reiniciar");
		mntmRiniciar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_MASK | InputEvent.ALT_MASK));

		mnVotos.add(mntmRiniciar);

		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);

		JMenuItem mntmVotosHelp = new JMenuItem("Votos Help");
		mntmVotosHelp.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H, InputEvent.CTRL_MASK | InputEvent.ALT_MASK));
		mntmVotosHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// OpenCHM.open("Pactometro/Pactometro.chm");

			}
		});
		mnHelp.add(mntmVotosHelp);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setForeground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setBounds(37, 11, 152, 291);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(0, 1, 0, 0));

		Votos progressBar = new Votos();
		progressBar.setBounds(37, 347, 365, 33);
		contentPane.add(progressBar);

		JCheckBox chckbxPesoe = new JCheckBox("PSOE");
		chckbxPesoe.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxPesoe.setBackground(Color.GRAY);
		chckbxPesoe.setForeground(Color.RED);

		panel.add(chckbxPesoe);

		JCheckBox chckbxPP = new JCheckBox("PP");
		chckbxPP.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxPP.setBackground(Color.GRAY);
		chckbxPP.setForeground(Color.BLUE);
		panel.add(chckbxPP);

		JCheckBox chckbxVox = new JCheckBox("VOX");
		chckbxVox.setFont(new Font("Century Gothic", Font.BOLD, 13));
		chckbxVox.setBackground(Color.GRAY);
		chckbxVox.setForeground(Color.GREEN);
		panel.add(chckbxVox);

		JCheckBox chckbxNewCheckBox = new JCheckBox("UP");
		chckbxNewCheckBox.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxNewCheckBox.setBackground(Color.GRAY);
		chckbxNewCheckBox.setForeground(Color.MAGENTA);
		panel.add(chckbxNewCheckBox);

		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("ERC");
		chckbxNewCheckBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxNewCheckBox_1.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textERC.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textERC.getText()));

				}
			}
		});
		chckbxNewCheckBox_1.setForeground(Color.YELLOW);
		chckbxNewCheckBox_1.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxNewCheckBox_1.setBackground(Color.GRAY);
		panel.add(chckbxNewCheckBox_1);

		JCheckBox chckbxCs = new JCheckBox("Cs");
		chckbxCs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxCs.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textCs.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textCs.getText()));

				}
			}
		});
		chckbxCs.setForeground(Color.ORANGE);
		chckbxCs.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxCs.setBackground(Color.GRAY);
		panel.add(chckbxCs);

		JCheckBox chckbxJxcat = new JCheckBox("JxCat");
		chckbxJxcat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxJxcat.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textJxCat.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textJxCat.getText()));

				}
			}
		});
		chckbxJxcat.setForeground(Color.CYAN);
		chckbxJxcat.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxJxcat.setBackground(Color.GRAY);
		panel.add(chckbxJxcat);

		JCheckBox chckbxPnv = new JCheckBox("PNV");
		chckbxPnv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxPnv.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textPNV.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textPNV.getText()));

				}
			}
		});
		chckbxPnv.setForeground(Color.PINK);
		chckbxPnv.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxPnv.setBackground(Color.GRAY);
		panel.add(chckbxPnv);

		JCheckBox chckbxBildu = new JCheckBox("Bildu");
		chckbxBildu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxBildu.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textBildu.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textBildu.getText()));

				}

			}
		});
		chckbxBildu.setForeground(Color.DARK_GRAY);
		chckbxBildu.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxBildu.setBackground(Color.GRAY);
		panel.add(chckbxBildu);

		JCheckBox chckbxNewCheckBox_2 = new JCheckBox("MP");
		chckbxNewCheckBox_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxNewCheckBox_2.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textMP.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textMP.getText()));

				}

			}
		});
		chckbxNewCheckBox_2.setForeground(Color.BLACK);
		chckbxNewCheckBox_2.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxNewCheckBox_2.setBackground(Color.GRAY);
		panel.add(chckbxNewCheckBox_2);

		JCheckBox chckbxCup = new JCheckBox("CUP");
		chckbxCup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxCup.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textCUP.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textCUP.getText()));

				}

			}
		});
		chckbxCup.setForeground(Color.RED);
		chckbxCup.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxCup.setBackground(Color.GRAY);
		panel.add(chckbxCup);

		JCheckBox chckbxCc = new JCheckBox("CC");
		chckbxCc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxCc.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textField_11.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textField_11.getText()));

				}

			}
		});
		chckbxCc.setForeground(Color.BLUE);
		chckbxCc.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxCc.setBackground(Color.GRAY);
		panel.add(chckbxCc);

		JCheckBox chckbxNa = new JCheckBox("NA");
		chckbxNa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxNa.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textField_12.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textField_12.getText()));

				}

			}
		});
		chckbxNa.setForeground(Color.GREEN);
		chckbxNa.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxNa.setBackground(Color.GRAY);
		panel.add(chckbxNa);

		JCheckBox chckbxBng = new JCheckBox("BNG");
		chckbxBng.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxBng.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textField_13.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textField_13.getText()));

				}

			}
		});
		chckbxBng.setForeground(Color.MAGENTA);
		chckbxBng.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxBng.setBackground(Color.GRAY);
		panel.add(chckbxBng);

		JCheckBox chckbxPrc = new JCheckBox("PRC");
		chckbxPrc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxPrc.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textField_14.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textField_14.getText()));

				}

			}
		});
		chckbxPrc.setForeground(Color.YELLOW);
		chckbxPrc.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxPrc.setBackground(Color.GRAY);
		panel.add(chckbxPrc);

		JCheckBox chckbxTe = new JCheckBox("TE");
		chckbxTe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxTe.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textField_15.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textField_15.getText()));

				}
			}
		});
		chckbxTe.setForeground(Color.ORANGE);
		chckbxTe.setFont(new Font("Century Gothic", Font.BOLD, 14));
		chckbxTe.setBackground(Color.GRAY);
		panel.add(chckbxTe);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.GRAY);
		panel_1.setBounds(246, 11, 156, 284);
		contentPane.add(panel_1);
		panel_1.setLayout(new GridLayout(0, 1, 0, 0));

		textPsoe = new JTextField();
		textPsoe.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textPsoe.setBackground(Color.GRAY);
		textPsoe.setForeground(Color.RED);
		textPsoe.setEditable(false);
		textPsoe.setText("120");
		panel_1.add(textPsoe);
		textPsoe.setColumns(10);

		textPP = new JTextField();
		textPP.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textPP.setBackground(Color.GRAY);
		textPP.setForeground(Color.BLUE);
		textPP.setEditable(false);
		textPP.setText("88");
		panel_1.add(textPP);
		textPP.setColumns(10);

		textVox = new JTextField();
		textVox.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textVox.setBackground(Color.GRAY);
		textVox.setForeground(Color.GREEN);
		textVox.setEditable(false);
		textVox.setText("52");
		panel_1.add(textVox);
		textVox.setColumns(10);

		textUP = new JTextField();
		textUP.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textUP.setBackground(Color.GRAY);
		textUP.setForeground(Color.MAGENTA);
		textUP.setEditable(false);
		textUP.setText("35");
		panel_1.add(textUP);
		textUP.setColumns(10);

		textERC = new JTextField();
		textERC.setForeground(Color.YELLOW);
		textERC.setText("13");
		textERC.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textERC.setBackground(Color.GRAY);
		textERC.setEditable(false);
		panel_1.add(textERC);
		textERC.setColumns(10);

		textCs = new JTextField();
		textCs.setForeground(Color.ORANGE);
		textCs.setText("10");
		textCs.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textCs.setBackground(Color.GRAY);
		textCs.setEditable(false);
		panel_1.add(textCs);
		textCs.setColumns(10);

		textJxCat = new JTextField();
		textJxCat.setForeground(Color.CYAN);
		textJxCat.setText("8");
		textJxCat.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textJxCat.setBackground(Color.GRAY);
		textJxCat.setEditable(false);
		panel_1.add(textJxCat);
		textJxCat.setColumns(10);

		textPNV = new JTextField();
		textPNV.setForeground(Color.PINK);
		textPNV.setText("7");
		textPNV.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textPNV.setBackground(Color.GRAY);
		textPNV.setEditable(false);
		panel_1.add(textPNV);
		textPNV.setColumns(10);

		textBildu = new JTextField();
		textBildu.setForeground(Color.DARK_GRAY);
		textBildu.setText("5");
		textBildu.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textBildu.setBackground(Color.GRAY);
		textBildu.setEditable(false);
		panel_1.add(textBildu);
		textBildu.setColumns(10);

		textMP = new JTextField();
		textMP.setForeground(Color.BLACK);
		textMP.setText("3");
		textMP.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textMP.setBackground(Color.GRAY);
		textMP.setEditable(false);
		panel_1.add(textMP);
		textMP.setColumns(10);

		textCUP = new JTextField();
		textCUP.setForeground(Color.RED);
		textCUP.setText("2");
		textCUP.setEditable(false);
		textCUP.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textCUP.setBackground(Color.GRAY);
		panel_1.add(textCUP);
		textCUP.setColumns(10);

		textField_11 = new JTextField();
		textField_11.setForeground(Color.BLUE);
		textField_11.setText("2");
		textField_11.setEditable(false);
		textField_11.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textField_11.setBackground(Color.GRAY);
		panel_1.add(textField_11);
		textField_11.setColumns(10);

		textField_12 = new JTextField();
		textField_12.setForeground(Color.GREEN);
		textField_12.setText("2");
		textField_12.setEditable(false);
		textField_12.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textField_12.setBackground(Color.GRAY);
		panel_1.add(textField_12);
		textField_12.setColumns(10);

		textField_13 = new JTextField();
		textField_13.setForeground(Color.MAGENTA);
		textField_13.setText("1");
		textField_13.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textField_13.setBackground(Color.GRAY);
		panel_1.add(textField_13);
		textField_13.setColumns(10);

		textField_14 = new JTextField();
		textField_14.setForeground(Color.YELLOW);
		textField_14.setText("1");
		textField_14.setEditable(false);
		textField_14.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textField_14.setBackground(Color.GRAY);
		panel_1.add(textField_14);
		textField_14.setColumns(10);

		textField_15 = new JTextField();
		textField_15.setForeground(Color.ORANGE);
		textField_15.setText("1");
		textField_15.setEditable(false);
		textField_15.setFont(new Font("Century Gothic", Font.BOLD, 14));
		textField_15.setBackground(Color.GRAY);
		panel_1.add(textField_15);
		textField_15.setColumns(10);

		JButton btnReinicial = new JButton("Reiniciar");
		btnReinicial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				progressBar.reiniciar();
				chckbxBng.setSelected(false);
				chckbxNa.setSelected(false);
				chckbxCc.setSelected(false);
				chckbxCup.setSelected(false);
				chckbxPrc.setSelected(false);
				chckbxTe.setSelected(false);
				chckbxNewCheckBox_1.setSelected(false);
				chckbxJxcat.setSelected(false);
				chckbxPnv.setSelected(false);
				chckbxCs.setSelected(false);
				chckbxBildu.setSelected(false);
				chckbxNewCheckBox_2.setSelected(false);
				chckbxPesoe.setSelected(false);
				chckbxPP.setSelected(false);
				chckbxVox.setSelected(false);
				chckbxNewCheckBox.setSelected(false);
			}
		});
		btnReinicial.setBounds(37, 313, 365, 23);
		contentPane.add(btnReinicial);

		chckbxPesoe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (chckbxPesoe.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textPsoe.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textPsoe.getText()));

				}
			}
		});
		chckbxPP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (chckbxPP.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textPP.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textPP.getText()));
				}
			}
		});
		chckbxVox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (chckbxVox.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textVox.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textVox.getText()));

				}

			}
		});
		chckbxNewCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (chckbxNewCheckBox.isSelected()) {
					progressBar.setValue(progressBar.getValue() + Integer.parseInt(textUP.getText()));
				} else {
					progressBar.setValue(progressBar.getValue() - Integer.parseInt(textUP.getText()));

				}

			}
		});
		mntmRiniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				progressBar.reiniciar();
				chckbxBng.setSelected(false);
				chckbxNa.setSelected(false);
				chckbxCc.setSelected(false);
				chckbxCup.setSelected(false);
				chckbxPrc.setSelected(false);
				chckbxTe.setSelected(false);
				chckbxNewCheckBox_1.setSelected(false);
				chckbxJxcat.setSelected(false);
				chckbxPnv.setSelected(false);
				chckbxCs.setSelected(false);
				chckbxBildu.setSelected(false);
				chckbxNewCheckBox_2.setSelected(false);
				chckbxPesoe.setSelected(false);
				chckbxPP.setSelected(false);
				chckbxVox.setSelected(false);
				chckbxNewCheckBox.setSelected(false);
			}
		});

	}
}