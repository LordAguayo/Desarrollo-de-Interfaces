atpackage Pactometro;

import java.awt.Color;

import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Clase para poder modificar el valor y los colores que utilizara el elemento
 * progressBar
 * 
 * @author gonza
 *
 */
public class Votos extends JProgressBar implements ChangeListener {
	// VARIABLES PRIVADAS PARA USO
	// Variable de Mayoria M�xima.
	private int MayMax = 350;
	// Variable de Mayoria M�nima.
	private int MayMin = 176;

	public Votos() {
		this.setValue(0);
		this.setStringPainted(true);
		this.setMaximum(MayMax);
		this.addChangeListener(this);

	}

	/**
	 * M�todo que reinicia la barra a cero
	 */
	public void reiniciar() {
		this.setValue(0);
		this.setMaximum(MayMax);
		this.addChangeListener(this);
		this.setStringPainted(true);
	}

	/**
	 * M�todo para modificar los colores segun los valores que lleve en ese momento.
	 * 
	 * @param
	 */

	@Override
	public void stateChanged(ChangeEvent A) {
		if (this.getForeground() != Color.green && this.getValue() >= 176) {
			JOptionPane.showMessageDialog(null, "Has alcanzado la Mayoria Absoluta, tienes gobierno.");
		}
		if (this.getValue() < 20) {
			this.setForeground(Color.RED);
		} else if (this.getValue() < 40) {
			this.setForeground(Color.ORANGE);
		} else if (this.getValue() < 80) {
			this.setForeground(Color.YELLOW);
		} else if (this.getValue() < 100) {
			this.setForeground(Color.MAGENTA);
		} else if (this.getValue() < 120) {
			this.setForeground(Color.PINK);
		} else if (this.getValue() < 140) {
			this.setForeground(Color.CYAN);
		} else if (this.getValue() < 175) {
			this.setForeground(Color.BLUE);
		} else {
			this.setForeground(Color.GREEN);
		}

	}

}
