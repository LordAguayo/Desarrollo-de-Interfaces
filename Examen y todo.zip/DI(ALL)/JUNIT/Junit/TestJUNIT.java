package Junit;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


class TestJUNIT {

	@Test
	void test() {
		Suma suma = new Suma();
		double resultado = suma.getSuma(1.0, 1.0);
		assertEquals(2.0, resultado);
	}

}
