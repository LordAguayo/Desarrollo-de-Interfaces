package Junit;

public class Suma {

	public double getSuma(double d, double e) {
		// TODO Auto-generated method stub
		return d + e;
	}

}
