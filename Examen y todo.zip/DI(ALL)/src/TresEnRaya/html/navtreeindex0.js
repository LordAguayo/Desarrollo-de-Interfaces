var NAVTREEINDEX0 =
{
".html":[0,0,0],
"annotated.html":[0,0],
"class_tres_en_raya_1_1_tres_en_raya.html":[0,0,0,1],
"class_tres_en_raya_1_1_tres_en_raya.html#ac170d3ea6b3c72ed1f793e2147a5062d":[0,0,0,1,0],
"class_tres_en_raya_1_1metodos.html":[0,0,0,0],
"class_tres_en_raya_1_1metodos.html#aa8bc5601ec96fa478b9d5b31163d9f7f":[0,0,0,0,0],
"class_tres_en_raya_1_1metodos.html#aacc36e80493893eee8e2387899370dac":[0,0,0,0,1],
"classes.html":[0,1],
"functions.html":[0,3,0],
"functions_func.html":[0,3,1],
"hierarchy.html":[0,2],
"index.html":[],
"pages.html":[]
};
