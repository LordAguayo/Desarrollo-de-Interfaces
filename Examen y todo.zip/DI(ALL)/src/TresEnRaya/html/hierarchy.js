var hierarchy =
[
    [ "TresEnRaya.TresEnRaya", "class_tres_en_raya_1_1_tres_en_raya.html", null ],
    [ "ActionListener", null, [
      [ "TresEnRaya.metodos", "class_tres_en_raya_1_1metodos.html", null ]
    ] ],
    [ "JButton", null, [
      [ "TresEnRaya.metodos", "class_tres_en_raya_1_1metodos.html", null ]
    ] ]
];