var class_tres_en_raya_1_1_tres_en_raya =
[
    [ "TresEnRaya", "class_tres_en_raya_1_1_tres_en_raya.html#ac170d3ea6b3c72ed1f793e2147a5062d", null ]
];