var searchData=
[
  ['main_5',['main',['../class_tres_en_raya_1_1_tres_en_raya.html#affcfefba664c43f77a59d06c9a9289ad',1,'TresEnRaya::TresEnRaya']]]
];
