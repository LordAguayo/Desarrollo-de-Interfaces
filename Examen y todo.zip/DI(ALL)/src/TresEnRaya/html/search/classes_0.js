var searchData=
[
  ['metodos_3',['metodos',['../class_tres_en_raya_1_1metodos.html',1,'TresEnRaya']]]
];
