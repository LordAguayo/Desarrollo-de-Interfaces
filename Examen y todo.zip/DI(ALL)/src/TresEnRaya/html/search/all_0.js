var searchData=
[
  ['main_0',['main',['../class_tres_en_raya_1_1_tres_en_raya.html#affcfefba664c43f77a59d06c9a9289ad',1,'TresEnRaya::TresEnRaya']]],
  ['metodos_1',['metodos',['../class_tres_en_raya_1_1metodos.html',1,'TresEnRaya']]]
];
