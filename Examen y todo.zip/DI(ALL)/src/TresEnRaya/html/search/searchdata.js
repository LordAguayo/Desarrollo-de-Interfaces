var indexSectionsWithContent =
{
  0: "mt",
  1: "mt",
  2: "mt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Funciones"
};

