var annotated_dup =
[
    [ "TresEnRaya", null, [
      [ "metodos", "class_tres_en_raya_1_1metodos.html", "class_tres_en_raya_1_1metodos" ],
      [ "TresEnRaya", "class_tres_en_raya_1_1_tres_en_raya.html", "class_tres_en_raya_1_1_tres_en_raya" ]
    ] ]
];