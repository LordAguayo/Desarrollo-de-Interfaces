package Formulario;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;

public class formulario {
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private String[] comunidades_esp = { "Andaluc�a", "Arag�n", "Canarias", "Cantabria", "Castilla y Le�n",
			"Castilla-La Mancha", "Catalu�a", "Ceuta", "Comunidad Valenciana", "Comunidad de Madrid", "Extremadura",
			"Galicia", "Islas Baleares", "La Rioja", "Melilla", "Navarra", "Pa�s Vasco", "Principado de Asturias",
			"Regi�n de Murcia" };
	private String[] comunidades_por = { "Lisbon", "Porto", "Vila Nova de Gaia", "Braga", "Amadora", "Queluz",
			"Funchal", "Coimbra", "Set�bal", "Agualva-Cac�m", "Almada", "Rio Tinto", "Aveiro", "Viseu", "Odivelas",
			"Leiria", "Guimar�es", "Barreiro", "�vora", "Faro", "Portim�o and Ponta Delgada" };
	private FileWriter flwriter = null;
	private File f = new File(
			"C:\\Users\\gonza\\Documents\\IMF\\A�o 2\\Archivos Programacion de texto y dem�s\\formulario.txt");
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					formulario window = new formulario();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public formulario() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 333);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNombre = new JLabel("Nombre: ");
		lblNombre.setBounds(29, 31, 65, 19);
		frame.getContentPane().add(lblNombre);

		textField = new JTextField();
		textField.setBounds(116, 30, 130, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		textField.setText(textField.getText().toUpperCase());

		JLabel lblApellidos = new JLabel("Apellidos:");
		lblApellidos.setBounds(29, 61, 65, 14);
		frame.getContentPane().add(lblApellidos);

		textField_1 = new JTextField();
		textField_1.setBounds(116, 58, 130, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		textField_1.setText(textField_1.getText().toUpperCase());

		JLabel lblPais = new JLabel("Pais:");
		lblPais.setBounds(32, 119, 46, 14);
		frame.getContentPane().add(lblPais);

		JComboBox comboBox = new JComboBox();

		comboBox.setBounds(71, 116, 91, 20);
		frame.getContentPane().add(comboBox);
		comboBox.addItem("Espa�a");
		comboBox.addItem("Portugal");

		JLabel lblNewLabel = new JLabel("Region:");
		lblNewLabel.setBounds(219, 119, 46, 14);
		frame.getContentPane().add(lblNewLabel);

		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(275, 116, 90, 20);
		frame.getContentPane().add(comboBox_1);

		JRadioButton rdbtnMuejer = new JRadioButton("Mujer");
		rdbtnMuejer.setBounds(282, 57, 83, 23);
		frame.getContentPane().add(rdbtnMuejer);

		JRadioButton rdbtnHombre = new JRadioButton("Hombre");
		rdbtnHombre.setBounds(282, 29, 109, 23);
		frame.getContentPane().add(rdbtnHombre);

		JLabel lblElijeElTipo = new JLabel("Elije el tipo de transporte que utilizas:");
		lblElijeElTipo.setBounds(102, 147, 193, 14);
		frame.getContentPane().add(lblElijeElTipo);

		JCheckBox chckbxCoche = new JCheckBox("Coche");
		chckbxCoche.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int input = JOptionPane.showConfirmDialog(frame, "�Esta seguro?", "Cuidado", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (input == 1) {
					chckbxCoche.setSelected(false);
				}
			}
		});
		chckbxCoche.setBounds(29, 177, 97, 23);
		frame.getContentPane().add(chckbxCoche);

		JCheckBox chckbxMoto = new JCheckBox("Moto");
		chckbxMoto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int input = JOptionPane.showConfirmDialog(frame, "�Esta seguro?", "Cuidado", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (input == 1) {
					chckbxMoto.setSelected(false);
				}
			}
		});
		chckbxMoto.setBounds(143, 177, 97, 23);
		frame.getContentPane().add(chckbxMoto);

		JCheckBox chckbxPie = new JCheckBox("Pie");
		chckbxPie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int input = JOptionPane.showConfirmDialog(frame, "�Esta seguro?", "Cuidado", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (input == 1) {
					chckbxPie.setSelected(false);
				}
			}
		});
		chckbxPie.setBounds(268, 177, 97, 23);
		frame.getContentPane().add(chckbxPie);

		JCheckBox chckbxMetro = new JCheckBox("Metro");
		chckbxMetro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int input = JOptionPane.showConfirmDialog(frame, "�Esta seguro?", "Cuidado", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (input == 1) {
					chckbxMetro.setSelected(false);
				}
			}
		});
		chckbxMetro.setBounds(29, 216, 97, 23);
		frame.getContentPane().add(chckbxMetro);

		JCheckBox chckbxBus = new JCheckBox("Bus");
		chckbxBus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int input = JOptionPane.showConfirmDialog(frame, "�Esta seguro?", "Cuidado", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (input == 1) {
					chckbxBus.setSelected(false);
				}
			}
		});
		chckbxBus.setBounds(143, 216, 97, 23);
		frame.getContentPane().add(chckbxBus);

		JCheckBox chckbxOtro = new JCheckBox("Otro");
		chckbxOtro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int input = JOptionPane.showConfirmDialog(frame, "�Esta seguro?", "Cuidado", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (input == 1) {
					chckbxOtro.setSelected(false);
				}
			}
		});
		chckbxOtro.setBounds(268, 216, 97, 23);
		frame.getContentPane().add(chckbxOtro);

		ButtonGroup grupo1 = new ButtonGroup();
		grupo1.add(rdbtnHombre);
		grupo1.add(rdbtnMuejer);

		JButton btnClear = new JButton("Reset");
		buttonGroup.add(btnClear);
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				chckbxCoche.setSelected(false);
				chckbxPie.setSelected(false);
				chckbxMoto.setSelected(false);
				chckbxMetro.setSelected(false);
				chckbxBus.setSelected(false);
				chckbxOtro.setSelected(false);
				rdbtnMuejer.setSelected(false);
				rdbtnHombre.setSelected(false);
			}
		});
		btnClear.setBounds(37, 260, 89, 23);
		frame.getContentPane().add(btnClear);

		JButton btnGuardar = new JButton("Guardar");
		buttonGroup.add(btnGuardar);
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (btnGuardar.equals("Guardado")) {
					btnGuardar.setText("Hola");
				}
				try {
					flwriter = new FileWriter(f);
					BufferedWriter bw = new BufferedWriter(flwriter);
					bw.write(textField.getText().toString() + "\n");
					bw.write(textField_1.getText().toString() + "\n");
					if (rdbtnMuejer.isSelected()) {
						bw.write("Mujer" + "\n");
					} else {
						bw.write("Hombre" + "\n");
					}
					bw.write(comboBox.getSelectedItem().toString() + "\n");
					bw.write(comboBox_1.getSelectedItem().toString() + "\n");
					if (chckbxCoche.isSelected())
						bw.write("Coche" + "\n");
					if (chckbxBus.isSelected())
						bw.write("Bus" + "\n");
					if (chckbxPie.isSelected())
						bw.write("Pie" + "\n");
					if (chckbxMetro.isSelected())
						bw.write("Metro" + "\n");
					if (chckbxMoto.isSelected())
						bw.write("Moto" + "\n");
					if (chckbxOtro.isSelected())
						bw.write("Otro" + "\n");
					bw.close();
					btnGuardar.setText("Guardado");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnGuardar.setBounds(162, 260, 89, 23);
		frame.getContentPane().add(btnGuardar);

		JButton btnCargar = new JButton("Cargar");
		btnCargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try (BufferedReader br = new BufferedReader(new FileReader(f))) {
					String line = br.readLine();
					int lineas = 6;
					int i = 0;
					while (i <= 6)
						i++;
					line = br.readLine();
					br.close();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}
		});
		btnCargar.setBounds(294, 260, 89, 23);
		frame.getContentPane().add(btnCargar);

		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (comboBox.getSelectedItem().toString() == "Espa�a") {
					comboBox_1.removeAllItems();
					for (int i = 0; i < comunidades_esp.length; i++) {
						comboBox_1.addItem(comunidades_esp[i].toString());
					}
				} else {
					comboBox_1.removeAllItems();
					for (int i = 0; i < comunidades_por.length; i++) {
						comboBox_1.addItem(comunidades_por[i].toString());
					}
				}
			}
		});

	}
}
