package moledo;

import java.sql.SQLException;
import java.util.ArrayList;

import dao.DAOTarea;

public class ListaTareas {

	private ArrayList<Activity> lista;
	
}
