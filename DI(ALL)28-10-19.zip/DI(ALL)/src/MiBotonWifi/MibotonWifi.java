package MiBotonWifi;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class MibotonWifi extends JButton implements ActionListener {

	public MibotonWifi() {
		this.setText("ON");
		this.setForeground(Color.GREEN);
		this.setIcon(new ImageIcon(MibotonWifi.class
				.getResource("C:\\Users\\gonza\\eclipse-workspace\\DI(ALL)\\src\\Images\\wifiON.png")));
		addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (this.getText().contentEquals("OFF")) {
			this.setForeground(Color.GREEN);
			this.setText("ON");
			this.setIcon(new ImageIcon(MibotonWifi.class
					.getResource("C:\\Users\\gonza\\eclipse-workspace\\DI(ALL)\\src\\Images\\wifiON.png")));
		} else {
			this.setText("ON");
			this.setForeground(Color.RED);
			this.setIcon(new ImageIcon(MibotonWifi.class
					.getResource("C:\\Users\\gonza\\eclipse-workspace\\DI(ALL)\\src\\Images\\wifiOFF.png")));
		}

	}

}
