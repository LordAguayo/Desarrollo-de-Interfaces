package HotCold;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class tf_frio_calor extends JTextField implements KeyListener {
	int nrand;

	public tf_frio_calor() {
		this.reiniciar();
		this.addKeyListener(this);
	}

	private void reiniciar() {
		Random r = new Random();
		nrand = r.nextInt(101);
		System.out.println(nrand);
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {

	}

	// L�gica de la Aplicaci�n.
	@Override
	public void keyReleased(KeyEvent e) {
		int input = Integer.parseInt(this.getText());
		int diferencia = Math.abs(nrand - input);
		// Condiciones
		if (diferencia == 0) {
			setBackground(Color.GREEN);
			JOptionPane.showInternalMessageDialog(getParent(), "Eureka, Acertaste, sigue asi!!");
			reiniciar();
		}
		if (diferencia >= 5) {
			setBackground(Color.CYAN);
		}
		if (diferencia >= 10) {
			setBackground(Color.BLUE);
		}
		if (diferencia >= 15) {
			setBackground(Color.YELLOW);
		}
		if (diferencia >= 20) {
			setBackground(Color.ORANGE);
		}
		if (diferencia >= 25) {
			setBackground(Color.RED);
		}
		if (diferencia > 30) {
			setBackground(Color.GRAY);
		}
	}

}
