package Calcu;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;

public class interfazG {

	private JFrame frame;
	private JTextField textField;

	double n1;
	double n2;
	double total;
	String operacion;
	String answer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					interfazG window = new interfazG();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public interfazG() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 334, 484);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.RIGHT);
		textField.setBounds(0, 0, 318, 91);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		JButton btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn7.getText();
				textField.setText(EnterNumber);
			}
		});
		btn7.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn7.setBackground(SystemColor.activeCaption);
		btn7.setBounds(10, 189, 54, 52);
		frame.getContentPane().add(btn7);

		JButton btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn8.getText();
				textField.setText(EnterNumber);
			}
		});
		btn8.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn8.setBackground(SystemColor.activeCaption);
		btn8.setBounds(74, 189, 54, 52);
		frame.getContentPane().add(btn8);

		JButton btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn9.getText();
				textField.setText(EnterNumber);
			}
		});
		btn9.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn9.setBackground(SystemColor.activeCaption);
		btn9.setBounds(138, 189, 54, 52);
		frame.getContentPane().add(btn9);

		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn4.getText();
				textField.setText(EnterNumber);
			}
		});
		btn4.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn4.setBackground(SystemColor.activeCaption);
		btn4.setBounds(10, 252, 54, 52);
		frame.getContentPane().add(btn4);

		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn5.getText();
				textField.setText(EnterNumber);
			}
		});
		btn5.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn5.setBackground(SystemColor.activeCaption);
		btn5.setBounds(74, 252, 54, 52);
		frame.getContentPane().add(btn5);

		JButton btn6 = new JButton("6");
		btn6.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn6.getText();
				textField.setText(EnterNumber);
			}
		});
		btn6.setBackground(SystemColor.activeCaption);
		btn6.setBounds(137, 252, 54, 52);
		frame.getContentPane().add(btn6);

		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn1.getText();
				textField.setText(EnterNumber);
			}
		});
		btn1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn1.setBackground(SystemColor.activeCaption);
		btn1.setBounds(10, 315, 54, 52);
		frame.getContentPane().add(btn1);

		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn2.getText();
				textField.setText(EnterNumber);
			}
		});
		btn2.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn2.setBackground(SystemColor.activeCaption);
		btn2.setBounds(74, 315, 54, 52);
		frame.getContentPane().add(btn2);

		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn3.getText();
				textField.setText(EnterNumber);
			}
		});
		btn3.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn3.setBackground(SystemColor.activeCaption);
		btn3.setBounds(137, 315, 54, 52);
		frame.getContentPane().add(btn3);

		JButton btnPlus = new JButton("+");
		btnPlus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				n1 = Double.parseDouble(textField.getText());
				textField.setText("");
				operacion = ("+");
			}
		});
		btnPlus.setBackground(SystemColor.activeCaption);
		btnPlus.setBounds(238, 191, 54, 52);
		frame.getContentPane().add(btnPlus);

		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField.getText() + btn0.getText();
				textField.setText(EnterNumber);
			}
		});
		btn0.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn0.setBackground(SystemColor.activeCaption);
		btn0.setBounds(10, 380, 54, 52);
		frame.getContentPane().add(btn0);

		JButton BtnResta = new JButton("-");
		BtnResta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				n1 = Double.parseDouble(textField.getText());
				textField.setText("");
				operacion = ("-");
			}
		});
		BtnResta.setBackground(SystemColor.activeCaption);
		BtnResta.setBounds(238, 254, 54, 52);
		frame.getContentPane().add(BtnResta);

		JButton BtnMulti = new JButton("X");
		BtnMulti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				n1 = Double.parseDouble(textField.getText());
				textField.setText("");
				operacion = ("*");
			}
		});
		BtnMulti.setBackground(SystemColor.activeCaption);
		BtnMulti.setBounds(238, 317, 54, 52);
		frame.getContentPane().add(BtnMulti);

		JButton btnDiv = new JButton("/");
		btnDiv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				n1 = Double.parseDouble(textField.getText());
				textField.setText("");
				operacion = ("/");
			}
		});
		btnDiv.setBackground(SystemColor.activeCaption);
		btnDiv.setBounds(238, 382, 54, 52);
		frame.getContentPane().add(btnDiv);

		JButton btnResult = new JButton("=");
		btnResult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				n2 = Double.parseDouble(textField.getText());
				if(operacion == "+") {
					total = n1 + n2;
					answer = String.format("%.2f",total);
					textField.setText(answer);
				}
				else if (operacion == "-") {
					total = n1 - n2;
					answer = String.format("%.2f",total);
					textField.setText(answer);
				}
				else if (operacion == "*") {
					total = n1 * n2;
					answer = String.format("%.2f",total);
					textField.setText(answer);
				}
				else if(operacion == "/") {
					total = n1 / n2;
					answer = String.format("%.2f",total);
					textField.setText(answer);
				}
				
			}
		});
		btnResult.setBackground(SystemColor.activeCaption);
		btnResult.setBounds(138, 380, 54, 52);
		frame.getContentPane().add(btnResult);

		JButton btnComma = new JButton(",");
		btnComma.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnComma.setBackground(SystemColor.activeCaption);
		btnComma.setBounds(74, 380, 54, 52);
		frame.getContentPane().add(btnComma);

		JButton btnCe = new JButton("RESET");
		btnCe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText(null);
			}
		});
		btnCe.setBackground(SystemColor.activeCaption);
		btnCe.setBounds(10, 114, 103, 52);
		frame.getContentPane().add(btnCe);
		
		JButton btnBack = new JButton("DELETE");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String delete = null;
				if(textField.getText().length() > 0) {
					StringBuilder strB = new StringBuilder(textField.getText());
					strB.deleteCharAt(textField.getText().length() -1);
					delete = strB.toString();
					textField.setText(delete);
				}
				
				
			}
		});
		btnBack.setBackground(SystemColor.activeCaption);
		btnBack.setBounds(189, 114, 103, 52);
		frame.getContentPane().add(btnBack);
	}
}
