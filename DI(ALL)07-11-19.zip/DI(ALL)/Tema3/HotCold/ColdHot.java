package HotCold;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.TextArea;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;

/**
 * 
 * @author gonza
 *
 */

public class ColdHot extends JFrame {
	private tf_frio_calor textField;
	private int cont = 0;
	private JTextField textField_1;

	/**
	 * Lanza la aplicaci�n.
	 */
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ColdHot frame = new ColdHot();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Crea la interfaz.
	 */
	
	/**
	 * @param
	 * 
	 */
	public ColdHot() {
		setTitle("ColdHot");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 138);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnInicio = new JMenu("Inicio");
		menuBar.add(mnInicio);
		
		JMenuItem mntmNew = new JMenuItem("New");
		mntmNew.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
		mnInicio.add(mntmNew
				);
		getContentPane().setLayout(null);

		textField = new tf_frio_calor();
		textField.setBounds(10, 36, 235, 20);
		getContentPane().add(textField);
		textField.setColumns(10);

		JLabel lblBienvenidoAlHot = new JLabel("Bienvenido, introduce un numero para comenzar:");
		lblBienvenidoAlHot.setBounds(10, 11, 252, 14);
		getContentPane().add(lblBienvenidoAlHot);

		
		JLabel lblVidas = new JLabel("Puntos:");
		lblVidas.setBounds(324, 11, 81, 14);
		getContentPane().add(lblVidas);

		textField_1 = new JTextField();
		textField_1.setBounds(319, 36, 86, 20);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
	}
}
