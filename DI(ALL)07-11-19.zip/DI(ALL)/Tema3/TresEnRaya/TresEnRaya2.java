package TresEnRaya;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.SwingWorker.StateValue;
import javax.swing.plaf.nimbus.State;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Set;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JMenuBar;
import javax.swing.JMenu;

public class TresEnRaya2 {
	int cont = 1;
	JButton btnPause = new JButton("Pause");
	JButton btnResume = new JButton("Resume");
	JButton btnNewGame = new JButton("New Game");
	JButton btn1 = new JButton("1");
	JButton btn2 = new JButton("2");
	JButton btn3 = new JButton("3");
	JButton btn4 = new JButton("4");
	JButton btn5 = new JButton("5");
	JButton btn6 = new JButton("6");
	JButton btn7 = new JButton("7");
	JButton btn8 = new JButton("8");
	JButton btn9 = new JButton("9");
	boolean check = false;
	private JFrame frame;
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnGame = new JMenu("Game");
	private final JButton btnNewGame_1 = new JButton("New Game");
	private final JButton btnPause_1 = new JButton("Pause");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TresEnRaya2 window = new TresEnRaya2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TresEnRaya2() {
		initialize();
	}

	public boolean ganador(JButton bt1, JButton bt2, JButton bt3, JButton bt4, JButton bt5, JButton bt6, JButton bt7,
			JButton bt8, JButton bt9) {
		btn1 = bt1;
		btn2 = bt2;
		btn3 = bt3;
		btn4 = bt4;
		btn5 = bt5;
		btn6 = bt6;
		btn7 = bt7;
		btn8 = bt8;
		btn9 = bt9;
		for (int i = 0; i < 10; i++) {
			if (btn1.equals(btn2) && btn1.equals(btn3) || btn1.equals(btn4) && btn1.equals(btn7)
					|| btn1.equals(btn5) && btn1.equals(btn9) || btn2.equals(btn5) && btn2.equals(btn8)
					|| btn3.equals(btn5) && btn3.equals(btn7) || btn3.equals(btn6) && btn3.equals(btn9)
					|| btn4.equals(btn5) && btn4.equals(btn6) || btn7.equals(btn8) && btn7.equals(btn9)) {
				if (i % 2 == 0) {
					JOptionPane.showInternalMessageDialog(frame, "Victoria del jugador 1");
				} else {
					JOptionPane.showInternalMessageDialog(frame, "Victoria del jugador 2");
				}
			}
		}
		return check;

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 460, 480);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		// VARIABLES BOTONES.

		// Acciones

		// Pausa:
		btnPause.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnPause.setText("Paused");
				btnPause.setEnabled(false);
				btn1.setEnabled(false);
				btn2.setEnabled(false);
				btn3.setEnabled(false);
				btn4.setEnabled(false);
				btn5.setEnabled(false);
				btn6.setEnabled(false);
				btn7.setEnabled(false);
				btn8.setEnabled(false);
				btn9.setEnabled(false);

			}
		});
		btnPause.setBounds(0, 363, 148, 50);
		frame.getContentPane().add(btnPause);

		// Continuar
		btnResume.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnPause.setText("Pause");
				btnPause.setEnabled(true);
				btn1.setEnabled(true);
				btn2.setEnabled(true);
				btn3.setEnabled(true);
				btn4.setEnabled(true);
				btn5.setEnabled(true);
				btn6.setEnabled(true);
				btn7.setEnabled(true);
				btn8.setEnabled(true);
				btn9.setEnabled(true);
			}

		});
		btnResume.setBounds(147, 363, 150, 50);
		frame.getContentPane().add(btnResume);

		// Juego nuevo
		btnNewGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn1.setBackground(null);
				btn2.setBackground(null);
				btn3.setBackground(null);
				btn4.setBackground(null);
				btn5.setBackground(null);
				btn6.setBackground(null);
				btn7.setBackground(null);
				btn8.setBackground(null);
				btn9.setBackground(null);
				btn1.setEnabled(true);
				btn2.setEnabled(true);
				btn3.setEnabled(true);
				btn4.setEnabled(true);
				btn5.setEnabled(true);
				btn6.setEnabled(true);
				btn7.setEnabled(true);
				btn8.setEnabled(true);
				btn9.setEnabled(true);
				cont = 1;

			}
		});
		btnNewGame.setBackground(Color.GREEN);
		btnNewGame.setBounds(296, 363, 148, 50);
		frame.getContentPane().add(btnNewGame);

		// Boton 1
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cont % 2 == 0 && cont != 0) {
					btn1.setBackground(Color.RED);
				} else {
					btn1.setBackground(Color.BLUE);
				}
				btn1.setEnabled(false);
				cont++;
				ganador(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9);
			}
		});
		btn1.setBounds(13, 24, 117, 95);
		frame.getContentPane().add(btn1);

		// Boton 4

		btn4.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				if (cont % 2 == 0 && cont != 0) {
					btn4.setBackground(Color.RED);
				} else {
					btn4.setBackground(Color.BLUE);
				}
				btn4.setEnabled(false);
				cont++;
				ganador(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9);
			}
		});
		btn4.setBounds(13, 144, 117, 95);
		frame.getContentPane().add(btn4);

		// Boton 7
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cont % 2 == 0 && cont != 0) {
					btn7.setBackground(Color.RED);
				} else {
					btn7.setBackground(Color.BLUE);
				}
				btn7.setEnabled(false);
				cont++;
				ganador(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9);
			}
		});
		btn7.setBounds(13, 264, 117, 88);
		frame.getContentPane().add(btn7);

		// Boton 2
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cont % 2 == 0 && cont != 0) {
					btn2.setBackground(Color.RED);
				} else {
					btn2.setBackground(Color.BLUE);
				}
				btn2.setEnabled(false);
				cont++;
				ganador(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9);
			}
		});
		btn2.setBounds(158, 24, 117, 95);
		frame.getContentPane().add(btn2);

		// Boton 5
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cont % 2 == 0 && cont != 0) {
					btn5.setBackground(Color.RED);
				} else {
					btn5.setBackground(Color.BLUE);
				}
				btn5.setEnabled(false);
				cont++;
				ganador(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9);
			}
		});
		btn5.setBounds(158, 144, 117, 95);
		frame.getContentPane().add(btn5);

		// Boton 8
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cont % 2 == 0 && cont != 0) {
					btn8.setBackground(Color.RED);
				} else {
					btn8.setBackground(Color.BLUE);
				}
				btn8.setEnabled(false);
				cont++;
				ganador(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9);
			}
		});
		btn8.setBounds(158, 264, 117, 88);
		frame.getContentPane().add(btn8);

		// Boton 3
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cont % 2 == 0 && cont != 0) {
					btn3.setBackground(Color.RED);
				} else {
					btn3.setBackground(Color.BLUE);
				}
				btn3.setEnabled(false);
				cont++;
				ganador(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9);

			}
		});
		btn3.setBounds(305, 24, 117, 95);
		frame.getContentPane().add(btn3);

		// Boton 6

		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cont % 2 == 0 && cont != 0) {
					btn6.setBackground(Color.RED);
				} else {
					btn6.setBackground(Color.BLUE);
				}
				btn6.setEnabled(false);
				cont++;
				ganador(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9);

			}
		});
		btn6.setBounds(305, 144, 117, 95);
		frame.getContentPane().add(btn6);

		// Boton 9
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cont % 2 == 0 && cont != 0) {
					btn9.setBackground(Color.RED);
				} else {
					btn9.setBackground(Color.BLUE);
				}
				btn9.setEnabled(false);
				cont++;
				ganador(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9);

			}
		});
		btn9.setBounds(303, 264, 119, 88);
		frame.getContentPane().add(btn9);

		frame.setJMenuBar(menuBar);

		menuBar.add(mnGame);
		btnNewGame_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn1.setBackground(null);
				btn2.setBackground(null);
				btn3.setBackground(null);
				btn4.setBackground(null);
				btn5.setBackground(null);
				btn6.setBackground(null);
				btn7.setBackground(null);
				btn8.setBackground(null);
				btn9.setBackground(null);
				btn1.setEnabled(true);
				btn2.setEnabled(true);
				btn3.setEnabled(true);
				btn4.setEnabled(true);
				btn5.setEnabled(true);
				btn6.setEnabled(true);
				btn7.setEnabled(true);
				btn8.setEnabled(true);
				btn9.setEnabled(true);
			}
		});

		mnGame.add(btnNewGame_1);
		btnPause_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnPause.setText("Paused");
				btnPause.setEnabled(false);
				btn1.setEnabled(false);
				btn2.setEnabled(false);
				btn3.setEnabled(false);
				btn4.setEnabled(false);
				btn5.setEnabled(false);
				btn6.setEnabled(false);
				btn7.setEnabled(false);
				btn8.setEnabled(false);
				btn9.setEnabled(false);
			}
		});

		mnGame.add(btnPause_1);

		JButton btnResume_1 = new JButton("Resume");
		btnResume_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnPause.setText("Pause");
				btnPause.setEnabled(true);
				btn1.setEnabled(true);
				btn2.setEnabled(true);
				btn3.setEnabled(true);
				btn4.setEnabled(true);
				btn5.setEnabled(true);
				btn6.setEnabled(true);
				btn7.setEnabled(true);
				btn8.setEnabled(true);
				btn9.setEnabled(true);
			}
		});
		mnGame.add(btnResume_1);
	}
}
